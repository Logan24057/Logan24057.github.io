//=============================================================================
// TWings Plugins
// TWings_CoreLight.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc v1.00 (MZ) Update some of RMMV core functions
 * @author TWings (Pierre-Alain Huille)
 * @url https://twings.itch.io/
 *
 *
 * @help This plugin does not provide plugin commands.
 *
 * This plugin is custom made for "Memories of a silver Dragon"
 * It's not meant to be used not to be used anywhere else.
 *
 */
const TW = {};